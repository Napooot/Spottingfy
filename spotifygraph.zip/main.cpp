#include "curlFunctions.h"

int main() {
    curl_global_init(CURL_GLOBAL_DEFAULT); //initialize the libcurl functionality globally, only done once!!!

    std::string accessToken = getAccessToken();
    std::cout << "Access Token: " << accessToken << std::endl;

    std::vector<std::string> trackIds;
    //Rachels Playlist: 6daOzCdZgqy2eUYTXGRXiA
    //Workout Playlist: 2TgkaMuRCcakvnS0GeC6Fm
    //Vancouver Playlist: 5yRfuPMl8y8hOEUp6gvWQF
    //Sad: 18eemOS00Cj0J5WCvpGb3t
    requestPlaylistInfo(accessToken,"18eemOS00Cj0J5WCvpGb3t",trackIds);

    std::vector<Song> userList;
    getTracksAudioFeatures(trackIds,accessToken,userList);

    //opening dataBase
    vector<Song> dataBase = Song::createPlayList("Spottingfy_dataset.csv");
    std::cout << "FILES OPENED. Data Base Size: " << dataBase.size() <<  "\n\n";

    vector<string> newRecommendations;
    newRecommendations = Song::recommendPlayList(userList,dataBase,newRecommendations);

//    for(string i : newRecommendations) {
//        cout << i << endl;
//    }

    curl_global_cleanup(); //clean up global curl state, done once too
    return 0;
}
